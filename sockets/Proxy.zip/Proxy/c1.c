#include"header.h"
#define PORT 8080

int main(){
	int sfd;
	struct sockaddr_in saddr;
	socklen_t saddrlen=sizeof(saddr);
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd<0){
		printf("Server Socket creation error !\n");
		return -1;
	}
	
	saddr1.sin_family=AF_INET;
	saddr1.sin_port=htons(PORT);
	
	int bret=bind(sfd,(struct sockaddr *)&saddr,sizeof(saddr));
	if(bret < 0){
		printf("Bind with main server error !\n");
		return -1;
	}
	
	int cret=connect(sfd,(struct sockaddr *)&saddr,saddrlen);
	if(cret < 0){
      	printf("\nConnection with main server Failed \n");
     		return -1;
    	}
    	printf("Connected to Proxy...\n");
    	printf("Enter specil server Port : ");
    	char ssport[5];
    	fgets(ssport,5,stdin);
    	send(sfd,ssport,strlen(ssport)+1,0);
	fd_set readfds;
	FD_ZERO(&readfds);
	struct timeval t;
	t.tv_sec=500;
	t.tv_usec=0;
	while(1)
	{
		FD_SET(0,&readfds);
		FD_SET(sfd,&readfds);
		char buffer[100];
		if(FD_ISSET(0,&readfds))
		{
			fgets(buffer,100,stdin);
			send(sfd,buffer,strlen(buffer)+1,0);
			printf("to server : %s",buffer);
		}
		if(FD_ISSET(sfd,&readfds))
		{
			recv(sfd,buffer,100,0);
			printf("from server : %s",buffer);
		}
	}

return 0;
}
