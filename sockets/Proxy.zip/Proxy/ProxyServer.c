#include"header.h"
#include<pthread.h>
#define PORT 8080
#define MAXCLIENTS 2
#define p1 5001
#define p2 5002
#define p3 5003
#define p4 5004
#define p5 5005
int clientID[5]={-1};
int noofclients=0;
pthread_t tid[5];
int threadcnt=0;

void connecttoss(void *portnum){
	char pn[5]=(char *)portnum;
	
}

int main(){
	int sfd;
	struct sockaddr_in saddr;
	socklen_t len=sizeof(saddr);
	int opt=1;
	sfd=socket(AF_INET,SOCK_STREAM,0);
	if(sfd < 0){
		printf("Socket creation error ! \n");
		return -1;
	}
	saddr.sin_family=AF_INET;
	saddr.sin_port=htons(PORT);
	saddr.sin_addr.s_addr=INADDR_ANY;
	int opret;
	opret=setsockopt(sfd,SOL_SOCKET,SO_REUSEADDR | SO_REUSEPORT,&opt,sizeof(opt));
	if(opret < 0){
		perror("setsockopt"); 
      	exit(EXIT_FAILURE); 
	}
	int bret;
	bret=bind(sfd,(struct sockaddr *)&saddr,sizeof(saddr));
	if(bret < 0){
		printf("\nBind failed........\n");
		return -1;
	}
	int lret;
	lret=listen(sfd,MAXCLIENTS);
	if(lret<0){
		printf("Listen error !............\n");
		return -1;
	}
	
	while(1)
	{
		fcntl(sfd,F_SETFL,fcntl(sfd,F_GETFL,0)|O_NONBLOCK);
		int nsfd=accept(sfd,(struct sockaddr *)&saddr,(socklen_t *)&len);
		char portnum[5];
		if(nsfd>=0)
		{
			printf("CONNECTION ESTABLISHED with client!....\n");
			clientID[noofclients++]=nsfd;
			recv(nsfd,portnum,5,0);
			
			pthread_create(&tid[++threadcnt],NULL,connecttoss,portnum);
			
			
			
			
			
			int ssfd;
			struct sockaddr_in ssaddr;
			socklen_t sslen=sizeof(ssaddr);
			ssfd=socket(AF_INET,SOCK_STREAM,0);
			if(ssfd<0){
				printf("Special server socket error !\n");
				break;
			}
			int flag=1;
			switch(portnum)
			{
				case "5001":
					{
						ssaddr.sin_family=AF_INET;
						ssaddr.sin_port=htons(p1);
						int sbret;
						sbret=bind(ssfd,(struct sockaddr *)&ssaddr,sizeof(ssaddr));
						if(sbret<0)
						{
							printf("Special server socket error !\n");
							flag=0;
							break;
						}
						int scret=connect(ssfd,(struct sockaddr *)&saddr,sslen);
						if(scret < 0){
      						printf("\nConnection special server Failed \n");
     							flag=0;
     							break;
    						}
    						printf("Connected to Special server...\n");
    						break;
					}
				case "5002":
					{
						ssaddr.sin_family=AF_INET;
						ssaddr.sin_port=htons(p2);
						int sbret;
						sbret=bind(ssfd,(struct sockaddr *)&ssaddr,sizeof(ssaddr));
						if(sbret<0)
						{
							printf("Special server socket error !\n");
							flag=0;
							break;
						}
						int scret=connect(ssfd,(struct sockaddr *)&saddr,sslen);
						if(scret < 0){
      						printf("\nConnection special server Failed \n");
							flag=0;     							
     							break;
    						}
    						printf("Connected to Special server...\n");	
						break;
					}
				case "5003":
					{
						ssaddr.sin_family=AF_INET;
						ssaddr.sin_port=htons(p3);
						int sbret;
						sbret=bind(ssfd,(struct sockaddr *)&ssaddr,sizeof(ssaddr));
						if(sbret<0)
						{
							printf("Special server socket error !\n");
							flag=0;
							break;
						}
						int scret=connect(ssfd,(struct sockaddr *)&saddr,sslen);
						if(scret < 0){
      						printf("\nConnection special server Failed \n");
     							flag=0;
     							break;
    						}
    						printf("Connected to Special server...\n");	
						break;
					}
				case "5004":
					{
						ssaddr.sin_family=AF_INET;
						ssaddr.sin_port=htons(p4);
						int sbret;
						sbret=bind(ssfd,(struct sockaddr *)&ssaddr,sizeof(ssaddr));
						if(sbret<0)
						{
							printf("Special server socket error !\n");
							flag=0;
							break;
						}
						int scret=connect(ssfd,(struct sockaddr *)&saddr,sslen);
						if(scret < 0){
      						printf("\nConnection special server Failed \n");
     							flag=0;
     							break;
    						}
    						printf("Connected to Special server...\n");	
						break;
					}
				case "5005":
					{
						ssaddr.sin_family=AF_INET;
						ssaddr.sin_port=htons(p5);
						int sbret;
						sbret=bind(ssfd,(struct sockaddr *)&ssaddr,sizeof(ssaddr));
						if(sbret<0)
						{
							printf("Special server socket error !\n");
							flag=0;
							break;
						}
						int scret=connect(ssfd,(struct sockaddr *)&saddr,sslen);
						if(scret < 0){
      						printf("\nConnection special server Failed \n");
     							flag=0;
     							break;
    						}
    						printf("Connected to Special server...\n");	
						break;
					}			
			}
			
			if(flag)
			{
			
			
			}	
		}
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
return 0;
}
